# jogoMemoriaNumeral
Aplicação simula um jogo da memoria com números, objeto de estudo utilizando classe Handler e Thread em Java para desenvolvimento android. 
